#ifndef __APP_DATAPROCESS_H__
#define __APP_DATAPROCESS_H__

#include "Inf_JoyStickAndKey.h"

void App_DataProcess_Start(void);
void App_DataProcess_JoyStickDataProcess(void);
void App_DataProcess_KeyDataProcess(void);

#endif
